import cv2
import time
import os
from ament_index_python.packages import get_package_share_directory

class StandaloneColorSegmentation:
    def __init__(self):
 

        self.default_image_path = os.path.join('bed_pic.jpg')
        
        self.get_logger_info('独立颜色分割工具已初始化')

    def get_logger_info(self, msg):
        print(f"[INFO] [{time.strftime('%H:%M:%S')}]: {msg}")

    def process_image(self, input_image_path=None):
        image_path = input_image_path or self.default_image_path
        
        if not os.path.exists(image_path):
            self.get_logger_info(f'错误: 找不到图像文件 {image_path}')
            return None
            
        cv_image = cv2.imread(image_path)
        if cv_image is None:
            self.get_logger_info(f'错误: 无法读取图像文件 {image_path}')
            return None
            
        self.get_logger_info(f'成功加载图像: {image_path}')

        start_time = time.time()
        self.get_logger_info('开始处理图像...')

        hsv_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2HSV)
        img_h, img_s, img_v = cv2.split(hsv_image)
        
        mask_h = cv2.inRange(img_h, 150, 180)
        mask_s = cv2.inRange(img_s, 50, 255)
        mask_v = cv2.inRange(img_v, 150, 255)
        
        mask_h_and_s = cv2.bitwise_and(mask_h, mask_s)
        mask = cv2.bitwise_and(mask_h_and_s, mask_v)
        
        out_image = cv2.bitwise_and(cv_image, cv_image, mask=mask)

        use_time = time.time() - start_time
        self.get_logger_info(f'处理完成，共耗时: {use_time:.4f} 秒')
        
        output_path = "color_segmentation_result.jpg"
        cv2.imwrite(output_path, out_image)
        self.get_logger_info(f'结果已保存至: {output_path}')
        
        return out_image, use_time

    def show_result(self, image):
        if image is not None:
            cv2.imshow("StandaloneColorSegmentationResult", image)
            self.get_logger_info('按下 ESC 键退出显示...')
            cv2.waitKey(0)
            cv2.destroyAllWindows()

def main():
    processor = StandaloneColorSegmentation()
    
    result_img, use_time = processor.process_image()
    
    processor.show_result(result_img)

if __name__ == '__main__':
    main()