import cv2
import time
import os
from ament_index_python.packages import get_package_share_directory

class StandaloneImageProcessor:
    def __init__(self):
        self.default_image_path = os.path.join(
            'image.png'
        )
            
        self.get_logger_info('独立图像处理工具已初始化')

    def get_logger_info(self, msg):
        print(f"[INFO] [{time.strftime('%H:%M:%S')}]: {msg}")

    def process_image(self, input_image_path=None):
        image_path = input_image_path or self.default_image_path
        
        if not os.path.exists(image_path):
            self.get_logger_info(f'错误: 找不到图像文件 {image_path}')
            return None
            
        cv_image = cv2.imread(image_path)
        if cv_image is None:
            self.get_logger_info(f'错误: 无法读取图像文件 {image_path}')
            return None
            
        self.get_logger_info(f'成功加载图像: {image_path}')
        
        start_time = time.time()
        self.get_logger_info('开始处理图像...')


        gray_image = cv2.cvtColor(cv_image, cv2.COLOR_BGR2GRAY)
        binary2 = cv2.adaptiveThreshold(
            gray_image, 
            255, 
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
            cv2.THRESH_BINARY, 
            11, 
            2
        )
        
        contours, _ = cv2.findContours(binary2, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
        
        contour_scores = []
        for contour in contours:
            epsilon = 0.034 * cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, epsilon, True)
            
            if len(approx) == 6:
                area = cv2.contourArea(contour)
                if 800 < area < 2000:
                    x, y, w, h = cv2.boundingRect(contour)
                    aspect_ratio = float(w) / h if h > 0 else 0
                    score = area * (1 - abs(aspect_ratio - 1))
                    contour_scores.append((score, contour, (x, y, w, h)))

        contour_scores.sort(key=lambda x: x[0], reverse=True)
        
        for score, contour, (x, y, w, h) in contour_scores[:4]:
            cv2.rectangle(cv_image, (x, y), (x + w, y + h), (0, 0, 255), 2)

        use_time = time.time() - start_time
        self.get_logger_info(f'处理完成，共耗时: {use_time:.4f} 秒')
        
        output_path = "selected_image_2.jpg"
        cv2.imwrite(output_path, cv_image)
        self.get_logger_info(f'结果已保存至: {output_path}')
        
        return cv_image, use_time

    def show_result(self, image):
        if image is not None:
            cv2.imshow("selected_image_2", image)
            self.get_logger_info('按下 ESC 键退出显示...')
            cv2.waitKey(0)
            cv2.destroyAllWindows()

def main():
    processor = StandaloneImageProcessor()
    
    result_img, use_time = processor.process_image()
    
    processor.show_result(result_img)

if __name__ == '__main__':
    main()