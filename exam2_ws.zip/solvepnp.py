import cv2
import numpy as np

camera_matrix = np.array([
                [714.6266,    0.0,      336.0762],
                [0.0,         699.6977, 254.6305],
                [0.0,         0.0,      1.0]
            ])
dist_coeffs = np.array([-0.0722, -0.1798, 0.0, 0.0, 0.0]) 
rect_width = 30 
rect_height = 30  

object_points = np.array([
    [-rect_width / 2, -rect_height / 2, 0],
    [ rect_width / 2, -rect_height / 2, 0],
    [ rect_width / 2,  rect_height / 2, 0],
    [-rect_width / 2,  rect_height / 2, 0]
], dtype=np.float32)

cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("无法打开视频文件！")
    exit()

while True:
    ret, frame = cap.read()
    if not ret:
        break
        
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)
    edges = cv2.Canny(blurred, 50, 150)
    contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    for contour in contours:
        perimeter = cv2.arcLength(contour, True)
        approx = cv2.approxPolyDP(contour, 0.02 * perimeter, True)
        
        if len(approx) == 4 and cv2.contourArea(contour) > 500:
            image_points = approx.reshape(-1, 2).astype(np.float32)
            
            sorted_indices = np.lexsort((image_points[:, 1], image_points[:, 0]))
            
            try:
                success, rvec, tvec = cv2.solvePnP(object_points, image_points, camera_matrix, dist_coeffs)
                
                if success:

                    axis_length = rect_width / 2 
                    axis_3d_points = np.float32([[axis_length, 0, 0], [0, axis_length, 0], [0, 0, -axis_length]]).reshape(-1, 3)
           
                    imgpts, _ = cv2.projectPoints(axis_3d_points, rvec, tvec, camera_matrix, dist_coeffs)
                    
                    origin_pt, _ = cv2.projectPoints(np.array([[0,0,0]], dtype=np.float32), rvec, tvec, camera_matrix, dist_coeffs)
                    origin_pt = tuple(origin_pt[0].ravel().astype(int))
                    
                    cv2.line(frame, origin_pt, tuple(imgpts[0].ravel().astype(int)), (255, 0, 0), 3)
                    cv2.line(frame, origin_pt, tuple(imgpts[1].ravel().astype(int)), (0, 255, 0), 3)
                    cv2.line(frame, origin_pt, tuple(imgpts[2].ravel().astype(int)), (0, 0, 255), 3)
                    
            except Exception as e:
                pass

    cv2.imshow('finally_go_on', frame)
    if cv2.waitKey(30) == 27:
        break

cap.release()
cv2.destroyAllWindows()