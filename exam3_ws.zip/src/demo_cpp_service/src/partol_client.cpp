#include "rclcpp/rclcpp.hpp" 
#include "study4_interfaces/srv/partol.hpp"
#include <chrono>
#include <ctime>

using namespace std::chrono_literals;
using Partol = study4_interfaces::srv::Partol;


class PartolClient : public rclcpp::Node
{
public:
     explicit PartolClient(const std::string &node_name) : Node(node_name)
     {
        srand(time(NULL));
        partol_client_ = this->create_client<Partol>("partol");
        timer_ = this->create_wall_timer(10s, [&]()->void{
            while (!this->partol_client_->wait_for_service(1s))
            {
                if (!rclcpp::ok())
                {
                    RCLCPP_ERROR(this->get_logger(), "等待服务过程中,rclcpp404,退出");
                    return;
                }
                RCLCPP_INFO(this->get_logger(), "等待服务中...");   
            }

            auto request = std::make_shared<Partol::Request>();
            request->target_x = rand() % 14;
            request->target_y = rand() % 14;
            RCLCPP_INFO(this->get_logger(), "准备好目标点（%f,%f)",request->target_x,request->target_y); 
            this->partol_client_->async_send_request(request,[&](rclcpp::Client<Partol>::SharedFuture result_future)->void{
                auto response = result_future.get();
                if(response->result == Partol::Response::SUCESS){
                    RCLCPP_INFO(this->get_logger(), "请求目标点成功");
                };

                if(response->result == Partol::Response::FAIL){
                    RCLCPP_INFO(this->get_logger(), "请求目标点失败");
                };
            });
        });
     }
private:
    rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Client<Partol>::SharedPtr partol_client_;
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<PartolClient>("partol_client"));
    rclcpp::shutdown();
    return 0;
}