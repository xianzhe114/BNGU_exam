#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/twist.hpp"
#include "chrono"
#include "turtlesim/msg/pose.hpp" 
#include "study4_interfaces/srv/partol.hpp"
using Partol = study4_interfaces::srv::Partol;

using namespace std::chrono_literals;

class TurtleControl : public rclcpp::Node
{
public:
     explicit TurtleControl(const std::string &node_name) : Node(node_name)
     {
        service_ = this->create_service<Partol>("partol",[this](const Partol::Request::SharedPtr request,Partol::Response::SharedPtr response)->void{
            if((0<target_x_&&target_x_<12.0f)&&
            (0<target_y_&&target_y_<12.0f)){
                this -> target_x_= request ->target_x;
                this -> target_y_= request ->target_y;
                response->result =Partol::Response::SUCESS;
            }else{
                response->result =Partol::Response::FAIL;
            };
        },10);
        publisher_ =this->create_publisher<geometry_msgs::msg::Twist>("/turtle1/cmd_vel",10);
        subscription_ = this->create_subscription<turtlesim::msg::Pose>("/turtle1/pose",10,[this](const turtlesim::msg::Pose::SharedPtr pose){
            auto current_x_ = pose->x;
            auto current_y_ = pose->y;
            RCLCPP_INFO(get_logger(),"current_x:%f,current_y:%f",current_x_,current_y_);
            
            auto distance = std::sqrt(std::pow(current_x_ - target_x_,2) + std::pow(current_y_ - target_y_,2));

            auto angle = std::atan2(target_y_ - current_y_, target_x_ - current_x_)-pose->theta;

            auto msg = geometry_msgs::msg::Twist();
            if(distance > 0.1){
                if(fabs(angle) > 0.2){
                    msg.angular.z = fabs(angle);
                }else{
                    msg.linear.x = _k_ * distance;
                }
            }

            if(msg.linear.x > _max_speed_){
                msg.linear.x = _max_speed_;
            }

            publisher_->publish(msg);
        });
        // timer_ =this->create_wall_timer(1000ms,[this](){
        //     auto msg = geometry_msgs::msg::Twist();
        //     msg.linear.x = 1.0;
        //     msg.angular.z = 0.5;
        //     publisher_->publish(msg);
        // });
     }
private:
    // rclcpp::TimerBase::SharedPtr timer_;
    rclcpp::Service<Partol>::SharedPtr service_;
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr publisher_;
    rclcpp::Subscription<turtlesim::msg::Pose>::SharedPtr subscription_;
    double target_x_{1.0};
    double target_y_{1.0};
    double _k_{1.0};
    double _max_speed_{3.0};
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<TurtleControl>("turtle_control"));
    rclcpp::shutdown();
    return 0;
}