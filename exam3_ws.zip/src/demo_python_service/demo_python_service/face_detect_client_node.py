import rclpy
from rclpy.node import Node
from study4_interfaces.srv import FaceDetector
import face_recognition
import cv2
from ament_index_python.packages import get_package_share_directory
import os
from cv_bridge import CvBridge
import time
from rcl_interfaces.msg import SetParametersResult

class FaceDetectClientNode(Node):
    def __init__(self):
        super().__init__('face_detect_client_node')
        self.bridge = CvBridge()
        self.default_image_path = os.path.join(get_package_share_directory(
            'demo_python_service'),'resource','test1.jpg')
        self.get_logger().info(f"人脸检测客户端已启动")
        self.client = self.create_client(FaceDetector, 'face_detect')
        self.image = cv2.imread(self.default_image_path)

    def send_request(self):
        while self.client.wait_for_service(timeout_sec=1.0) is False:
            self.get_logger().info('人脸检测服务未启动')
        request = FaceDetector.Request()
        request.image = self.bridge.cv2_to_imgmsg(self.image)
        future = self.client.call_async(request)

        # while not future.done():
        #     time.sleep(0.1)

        def callback(future):
            response = future.result()
            self.get_logger().info(f"人脸检测数量：{response.number},共耗时：{response.use_time}秒")
            self.show_response(response)

        future.add_done_callback(callback)
        
        

    def show_response(self,response):
        for i in range(response.number):
            top = response.top[i]
            left = response.left[i]
            right = response.right[i]
            bottom = response.bottom[i]
            cv2.rectangle(self.image, (left, top), (right, bottom), (225, 0, 0), 4)

    def spin_with_display(self):
        try:
            while rclpy.ok():
                rclpy.spin_once(self,timeout_sec=0.1)

                if hasattr(self, 'image') and self.image is not None:
                    cv2.imshow('face_detect', self.image)
                    key = cv2.waitKey(1)

                    if key == ord('q') or key == 27:
                        self.get_logger().info('退出程序')
                        break

        except KeyboardInterrupt:
            pass
        finally:
            self.destroy_node()
            cv2.destroyAllWindows()

# int32[] top
# int32[] left
# int32[] right
# int32[] bottom

def main():
    rclpy.init()
    node = FaceDetectClientNode()
    node.send_request()
    node.spin_with_display()
    rclpy.shutdown()